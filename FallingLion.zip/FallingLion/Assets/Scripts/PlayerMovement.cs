﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{

    public float speed = 4f;
	public Rigidbody2D rb;
	public int score;
	public Text scoretext;

	Vector2 movement;

	void Start()
	{
		rb.gravityScale = 0f;
	}
	

    void Update()
    {
        movement.x = Input.GetAxisRaw("Horizontal");
		//movement.y = Input.GetAxisRaw("Vertical");
		
    }
	
	void GenerateRandomPosition() {
        
        int rNumX = Random.Range(-9, 9);
        int rNumY = Random.Range(-5, 5);

        transform.position = new Vector2(rNumX, rNumY);
    }

	void OnCollisionEnter2D(Collision2D target) {
        transform.position = new Vector2(0, 4);
		rb.gravityScale = 0;
		score++;
		scoretext.text = score.ToString();
    }
	
	
	void FixedUpdate()
	{
		rb.MovePosition(rb.position + movement * speed * Time.fixedDeltaTime);
		if (Input.GetKey(KeyCode.DownArrow)){
			rb.gravityScale = 15f;
		}
	}
	
}
